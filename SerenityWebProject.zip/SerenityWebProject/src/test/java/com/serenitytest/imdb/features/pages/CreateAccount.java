package com.serenitytest.imdb.features.pages;

import static org.junit.Assert.assertEquals;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class CreateAccount extends PageObject {

	@FindBy(id = "nblogin")
	WebElementFacade login;

	@FindBy(xpath = "//*[@id=\"signin-options\"]/div/h1")
	WebElementFacade signInTitle;

	@FindBy(xpath = "//*[@id=\"signin-options\"]/div/center/center/div[1]/a ")
	WebElementFacade createAccount;

	@FindBy(id = "ap_customer_name")
	WebElementFacade customerName;

	@FindBy(id = "ap_email")
	WebElementFacade customerEmail;

	@FindBy(id = "ap_password")
	WebElementFacade customerPassword;

	@FindBy(id = "ap_password_check")
	WebElementFacade reEnterPassword;

	@FindBy(id = "continue")
	WebElementFacade createImdbAccount;

	@FindBy(xpath = "//*[@id=\"navUserMenu\"]")
	WebElementFacade moveToUserMenu;

	@FindBy(xpath = "//*[@id=\"nblogout\"]")
	WebElementFacade logout;

	public void signIn() {
		login.click();
	}

	private void waitForVisibility(WebElement element) throws Error {
		new WebDriverWait(getDriver(), 60000000).until(ExpectedConditions.visibilityOf(element));
	}

	public void signInAssertion() {
		assertEquals("Sign in", signInTitle.getText());
	}

	public void createAccount() {
		waitForVisibility(createAccount);
		createAccount.click();
	}

	public void customerRegistration() throws IOException, InterruptedException {
		HSSFWorkbook workbook;

		HSSFSheet sheet;

		HSSFCell cell;

		File src = new File("C:\\Users\\Bluemoon\\eclipse-workspace\\SerenityWebProject\\TestAccount.xls");
		FileInputStream finput = new FileInputStream(src);
		workbook = new HSSFWorkbook(finput);
		sheet = workbook.getSheetAt(0);
		for (int i = 0; i <= sheet.getLastRowNum(); i++) {

			cell = sheet.getRow(i).getCell(1);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			customerName.clear();
			customerName.sendKeys(cell.getStringCellValue());

			cell = sheet.getRow(i).getCell(2);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			customerEmail.clear();
			customerEmail.sendKeys(cell.getStringCellValue());

			cell = sheet.getRow(i).getCell(3);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			customerPassword.clear();
			customerPassword.sendKeys(cell.getStringCellValue());

			cell = sheet.getRow(i).getCell(4);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			reEnterPassword.clear();
			reEnterPassword.sendKeys(cell.getStringCellValue());

			createImdbAccount.click();

		}
	}

	public void logout() {
		Actions action = new Actions(getDriver());
		waitForVisibility(moveToUserMenu);
		action.moveToElement(moveToUserMenu).perform();
		waitForVisibility(logout);
		action.moveToElement(logout).click().perform();
	}

}