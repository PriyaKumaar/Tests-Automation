package com.serenitytest.imdb.features.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("http://www.imdb.com")
public class HomePage extends PageObject {

}
