package com.serenitytest.imdb.features.pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class Submenu extends PageObject {

	@FindBy(xpath = "//*[@id=\"navTitleMenu\"]/span")
	WebElementFacade moviesAndTvShow;

	@FindBy(xpath = "/html/body/div[1]/div/div[1]/div[2]/div[1]/ul/li[2]/div/div[3]/ul[1]/li[3]/a")
	WebElementFacade mostPopularTvShow;

	@FindBy(xpath = "//*[@id=\"main\"]/div/span/div/div/div[3]/table/tbody/tr[1]/td[2]/a ")
	WebElementFacade walkingDead;

	@FindBy(xpath = "//*[@id=\"title-overview-widget\"]/div[3]/div[1]/div[2]")
	WebElementFacade creator;

	public void clickOnMoviesAndTvShow() {

		Actions action = new Actions(getDriver());
		waitForVisibility(moviesAndTvShow);
		action.moveToElement(moviesAndTvShow).perform();
		waitForVisibility(mostPopularTvShow);
		action.moveToElement(mostPopularTvShow).click().perform();
	}

	private void waitForVisibility(WebElement element) throws Error {
		new WebDriverWait(getDriver(), 200000).until(ExpectedConditions.visibilityOf(element));
	}

	public void clickWalkingDead() {
		waitForVisibility(walkingDead);
		walkingDead.click();

	}

	public void Textassertion() {
		assertEquals("Creator: Frank Darabont", creator.getText());
	}

}