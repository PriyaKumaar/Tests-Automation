package com.serenitytest.imdb.features.UserTestSteps;

import java.io.IOException;

import com.serenitytest.imdb.features.steps.MainUserSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class UserTestSteps {

	@Steps

	MainUserSteps user;

	@Given("^User is on home page$")
	public void user_is_on_home_page() {
		user.openHomepage();

	}

	@When("^Click other sigin options$")
	public void click_other_sigin_options(){
		user.otherSigin();

	}

	@Then("^User navigate to registration/sigin page$")
	public void user_navigate_to_registration_sigin_page() {
		user.createAccountAssertion();
	}

	@Then("^Click on create account$")
	public void click_on_create_account(){
		user.createAccountClick();
	}
	@Then("^User gives valid data and click create account$")
	public void user_gives_valid_data_and_click_create_account() throws IOException, InterruptedException{
		user.registrationPage();
	    
	}


	
	@Then("^user should logout successfully$")
	public void user_should_logout_successfully(){
		user.logout();
	}
	
	@Given("^User is on home page2$")
	public void user_is_on_home_page2() {
		user.openHomepage();

	}

	@When("^Click \"Movies,Tv and showTimes and Click on Most popular Tv shows$")
	public void click_Movies_Tv_and_showTimes() {
		user.clickmoviesandtvshow();
	}

	@Then("^Click on The Walking Dead$")
	public void click_on_The_Walking_Dead() {
	user.clickwalkingdead();
	    
	}
	@Then("^verify Creator: Frank Darabont displays in details page$")
	public void verify_Creator_Frank_Darabont_displays_in_details_page()  {
	    user.Textassertion();
	}
	@Given("^User is again on home page")
	public void user_is_again_on_home_page(){
	    
	 user.openHomepage();   
	}

	@When("^Select Tv epsiodes from All menu$")
	public void select_Tv_epsiodes_from_All_menu(){
	 user.selectTvEpsiode();
	}
	@Then("^Type Walkind dead on the top search field$")
	public void type_Walkind_dead_on_the_top_search_field(){
user.searchTvEpsiode();	
}
	@Then("^verify Walkind Dead\\((\\d+)\\)\\(TV Epsiode\\) listed in the test result$")
	public void verify_Walkind_Dead_TV_Epsiode_listed_in_the_test_result(int arg1){
		user.assertion();

	}




 	}


