package com.serenitytest.imdb.features.pages;

import static org.junit.Assert.assertEquals;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class Search extends PageObject {
	
	@FindBy(xpath = "//*[@id=\"quicksearch\"]")
	WebElementFacade movieAllSearch;

	@FindBy(xpath = "//*[@id=\"navbar-query\"]")
	WebElementFacade searchButton;
	
	@FindBy(xpath = "//*[@id=\"navbar-submit-button\"]/div")
	WebElementFacade searchButtonClick;
	
	@FindBy(xpath= "/html/body/div[1]/div/div[4]/div[3]/div[1]/div/div[2]/table/tbody/tr[1]/td[2]/a")
	WebElementFacade assertionText;
	
	public void selectTvEpsiode()
	{
		movieAllSearch.click();
		movieAllSearch.selectByVisibleText("TV Episodes");
	}
	public void searchString(String values)
	{
		 typeInto(searchButton, values);
		 searchButtonClick.click();
	}
	public void assertion()
	{
		assertEquals("Walking Dead", assertionText.getText());
	}

	
		
	}



