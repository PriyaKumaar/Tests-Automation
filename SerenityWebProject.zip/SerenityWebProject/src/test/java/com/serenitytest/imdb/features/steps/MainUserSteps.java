package com.serenitytest.imdb.features.steps;

import java.io.IOException;

import com.serenitytest.imdb.features.pages.CreateAccount;
import com.serenitytest.imdb.features.pages.HomePage;
import com.serenitytest.imdb.features.pages.Search;
import com.serenitytest.imdb.features.pages.Submenu;

import net.thucydides.core.annotations.Step;

public class MainUserSteps {

	HomePage homePage;
	Submenu subMenu;
	Search search;
	@Step
	public void openHomepage() {
		homePage.open();
	}
	@Step
	public void clickmoviesandtvshow() 
	{
		subMenu.clickOnMoviesAndTvShow();
	}

	@Step
	public void clickwalkingdead() {
		subMenu.clickWalkingDead();
	}

	@Step
	public void Textassertion(){
		subMenu.Textassertion();
	}

	CreateAccount createAccount;
	
	@Step
	public void otherSigin() 
	{
		createAccount.signIn();
	}

	@Step
	public void createAccountAssertion() {
		createAccount.signInAssertion();
	}

	@Step
	public void createAccountClick(){
		createAccount.createAccount();
	}

	@Step
	public void registrationPage() throws IOException, InterruptedException{
		createAccount.customerRegistration();
	}

	@Step
	public void logout()
	{
		createAccount.logout();
	}
	@Step
	public void selectTvEpsiode()
	{
		search.selectTvEpsiode();
	}
	@Step
	public void searchTvEpsiode()
	{
		search.searchString("Walking Dead (2014)");
	}
	@Step
	public void assertion()
	{
		search.assertion();
	}

}